from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, DecimalType

spark = SparkSession.builder.appName("AlterTableExample").getOrCreate()

# Sample schema for the employees table
schema = StructType([
    StructField("id", IntegerType(), True),
    StructField("name", StringType(), True)
])

# Sample data for the employees table
data = [(1, "John Doe"), (2, "Jane Doe")]

# Create DataFrame
employees_df = spark.createDataFrame(data, schema)

# Add new column 'salary' with DecimalType
employees_df = employees_df.withColumn("salary", lit(None).cast(DecimalType(10, 2)))

# Show the updated DataFrame
employees_df.show()