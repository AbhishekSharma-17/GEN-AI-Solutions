from pyspark.sql import SparkSession
from pyspark.sql import Row

spark = SparkSession.builder.master("local").appName("example").getOrCreate()

# Create a DataFrame with the data
data = [Row(id=1, name='Alice', department='HR')]
df = spark.createDataFrame(data)

# Assuming the 'employees' table is a DataFrame, append the new row
employees = df  # In practice, you would load the existing DataFrame here

# Show the result
employees.show()