from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Initialize Spark session
spark = SparkSession.builder.appName("IncreaseSalary").getOrCreate()

# Sample data
data = [("John", "Engineering", 5000),
        ("Jane", "HR", 4000),
        ("Doe", "Engineering", 6000)]

# Create DataFrame
columns = ["name", "department", "salary"]
employees_df = spark.createDataFrame(data, columns)

# Increase salary by 10% for employees in the Engineering department
updated_employees_df = employees_df.withColumn(
    "salary",
    col("salary") * 1.10
).where(col("department") == "Engineering")

# Show updated DataFrame
updated_employees_df.show()

# Stop Spark session
spark.stop()